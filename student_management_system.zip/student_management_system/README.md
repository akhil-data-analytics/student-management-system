# Student Management System

Run `python main.py`. Default login: `admin` / `admin123`. The database file is created automatically. This project uses only Python standard-library modules.
